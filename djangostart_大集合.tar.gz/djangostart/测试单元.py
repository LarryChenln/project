###单元测试

import unittest

def myfunc(x,y):
    return x/y

class Testfun(unittest.TestCase):
    def test_int(self):
        self.assertEqual(myfunc(6,3),2)

    def test_float(self):
        self.assertEqual(myfunc(8.4,2),4.2)


if __name__ == '__main__':
    unittest.main()


import subprocess,os,sys

portcmd="netstat -nlt -p tcp|grep 31|awk '{print $2}'|head -1"
def zabbixSend(cmd):
    try:
        p=subprocess.Popen(cmd,stderr=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        status=p.communicate()
    except:
        status=0
    if status != 0:
        ### do something
        print('port is ok','port:',int(status[0]))
        ### example zabbix_send -s xxx.xx.x.x -k 'keyname' -o -value int(status[0]) -vv
    else:
        return False
    return 0

print(zabbixSend(portcmd))


###利用 UDP 协议来实现的，生成一个UDP包，把自己的 IP 放如到 UDP 协议头中，然后从UDP包中获取本机的IP。
###这个方法并不会真实的向外部发包，所以用抓包工具是看不到的

def get_host_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        # print(s.getsockname())
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip


###
#python3中为string.ascii_letters,而python2下则可以使用string.letters和string.ascii_letters
def GenPassword(length):
    import random
    import string
    chars=string.ascii_letters+string.digits
    return ''.join([random.choice(chars) for i in range(length)])#得出的结果中字符会有重复的

# print(GenPassword(8))

