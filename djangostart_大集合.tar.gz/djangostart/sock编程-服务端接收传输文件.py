import socket

sk=socket.socket()
ip_port=('127.0.0.1',9999)

sk.bind(ip_port)
sk.listen(5)
sum=1
while True:
    sum+=1
    ##当前连接
    conn,address=sk.accept()
    ##下面 while  ：一直使用当前连接进行数据接收
    while True:
        with open('/tmp/{file}'.format(file=sum),'ab') as f:
            data = conn.recv(1024)
            if data == b'quit':
                break
            f.write(data)
        conn.send('success'.encode())
    print('文件传输完成')
    sk.close()
