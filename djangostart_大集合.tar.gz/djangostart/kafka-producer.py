
from kafka import KafkaProducer
kafka_host = '172.17.7.72'  # host
kafka_port = 9092  # port

producer = KafkaProducer(bootstrap_servers=['{kafka_host}:{kafka_port}'.format(
    kafka_host=kafka_host,
    kafka_port=kafka_port
)])
nginx_topic='nginx'
message_string = 'hello lily'
response = producer.send(nginx_topic, message_string.encode('utf-8'))