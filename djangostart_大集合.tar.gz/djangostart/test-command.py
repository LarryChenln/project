# import pandas as pd
# import json
# import sys,os
# a=[2,5,7,3]
# b=[3,1,6,4]
#
# dataframe=pd.DataFrame({'apple':a,
#               'orange':b
#               })

# dataframe.to_csv('/tmp/file1.csv',index=False,sep=',')


# reader=pd.read_csv('/tmp/file1.csv')
# print(type(reader))
# print(reader.tail(2))



# pv_list=[3000,8000,8732,19802,33398]
# uv_list=[2000,3219,8731,3211,8873]
# time_list=['22/06/18','23/06/18','24/06/18','25/06/18','26/06/18']
#
# dataframe=pd.DataFrame({'time':time_list,'pv':pv_list,'uv':uv_list})
# dataframe.to_csv('/tmp/pdfile.csv',index=False,sep=',')




# with open('/tmp/pdfile.csv','r')as ff:
#     data=ff.readlines()
#     jdata=json.dumps(data)
#
#
#     dd=json.loads(jdata)
#     print(jdata)
#     print(dd)

# config={
#     'host':'172.17.0.2',
#     'port':3306,
#     "user":"test",
#     "password":"123456",
#     "database":"djangostart",
#     "charset":"utf8"
#
# }
#
# import pymysql
# import time
# now_time=int(time.time())
# ten_mins_time=int(now_time-600*60)
# print(now_time,ten_mins_time)
# conn=pymysql.connect(**config)
# cur=conn.cursor()
# ##select_sql="select VALUE from user_message where time=1hous and name=%s"
# select_sql="select collect_value from collect where UNIX_TIMESTAMP(create_time) < %d and UNIX_TIMESTAMP(create_time)  > %d and collect_key='%s' "
# distinctsql="select distinct(collect_key) from collect where UNIX_TIMESTAMP(create_time) < %d and UNIX_TIMESTAMP(create_time)  > %d"
# def getkeys(distinctsql,now_time,ten_mins_time):
#     keylist = []
#     leng=cur.execute(distinctsql %(now_time,ten_mins_time))
#     keylists=cur.fetchall()
#     # print(distinctsql %(now_time,ten_mins_time))
#     for i in range(leng):
#         # print(keylists[i][0])
#         keylist.append(keylists[i][0])
#     return keylist
# aa=getkeys(distinctsql,now_time,ten_mins_time)
# # print(aa)
#
# data={'172.17.88.192':
#     {'3306':
#         [
#         ]
# }}
#
# for line in range(len(aa)):
#     # if aa[line]:
#     resultNum=cur.execute(select_sql %(now_time,ten_mins_time,aa[line]))
#
#     result=cur.fetchall()
#     data['172.17.88.192']['3306'].insert(line,[aa[line]])
#     for i in range(resultNum):
#         data['172.17.88.192']['3306'][line].append(result[i][0])


# print(data)

#
# import subprocess,sys
#
# myping='ping -c 2'
#
# p=subprocess.call(myping+' www.baid3u.coe34m',stderr=subprocess.PIPE,stdout=sys.stdout,shell=True)
# print(p)

# queue=[x for x in range(11)]
# for i in range(11):
#     popnum=queue.pop()
#     print('removed [',popnum,']')
#
# d={'a':123,'b':456}
#
# for i in range('abc','123'):
#     print(i)


#
# class parent(object):
#     x=1
# class child1(parent):
#     pass
#
# class child2(parent):
#     pass
#
# print('','parent  :',parent.x,'\n','child 1 :',child1.x,'\n','child 2 :',child2.x)
# child1.x=8
# print('\n')
# print('','parent  :',parent.x,'\n','child 1 :',child1.x,'\n','child 2 :',child2.x)
# parent.x=99
# print('','parent  :',parent.x,'\n','child 1 :',child1.x,'\n','child 2 :',child2.x)


#
# temp=[lambda x:x+i for i in range(4)]
# for y in temp:
#     print(y(6))
#
#
#
#
# a=lambda x:x+x
# # print(a(2))
# import os
# for i in os.listdir('./'):
#     print(i)
#
#
#


# ###下载百度音乐歌词
# import requests, json,re
# keyword=input('请输入歌曲：')
# song_list=[]
# result='s'
# def getSongid(keyword):
#     URL = 'http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.search.catalogSug&query=%s'
#     data=requests.post(URL % (str(keyword)))
#     data=json.loads(data.text)
#     # print(data)
#
#     for n in data["song"]:
#         try:
#             artistname=n['artistname']
#             songid=n['songid']
#             songname=n['songname']
#             print(songname,'  ',artistname)
#             if artistname == '林琳' and songname == str(keyword):
#                 song_list.append(songid)
#         except KeyError:
#             pass
#     if len(song_list) > 0:
#         return song_list
#     else:
#         return 0
#
#
# def getLrc(songid):
#     # print(songid)
#     if songid != 0:
#         LRC_URL='http://tingapi.ting.baidu.com/v1/restserver/ting?method=baidu.ting.song.lry&songid=%d'
#         lrc_data=requests.post(LRC_URL % (int(songid)))
#         data=json.loads(lrc_data.text)
#         # print(data)
#         try:
#             title=data['title']
#             lrccontent=data['lrcContent']
#             regx=re.search('[\d\d:\d\d:\d\d]',lrccontent)
#             if regx:
#                 print('\r\n', title, '\r\n', lrccontent)
#                 result='ok'
#             else:
#                 return '未找到该歌曲的歌词\n\r请尝试其它歌曲名'
#         except KeyError:
#             return '暂未找到歌词'
#
#
#     else:
#         return '未找到该歌曲的歌词'
#
#
# def main():
#     getSongid(keyword)
#     for kw in song_list:
#         # print(result,'-'*60)
#         if result !='ok':
#             getLrc(kw)
#         else:
#             break
#
#
#
#
# if __name__ == '__main__':
#     main()
#

#
# inputFile=input('pls input a file name:')
# with open('{filename}'.format(filename=inputFile),'r')as f:
#     li=[]
#     for w in f.readlines():
#         li.append(w)
#     for i in range(len(li)):
#         word=li[i]
#         line=word.split(',')
#         name=line[0]
#         age=line[1]
#         sex=line[2]
#         city=line[3]
#         sql='insert into tb tongji values(%s,%s,%s,%s)' % (name,age,sex,city)
#         ### mysql-exec-sql
#         print(sql)
#

import pandas as pd
### 读取CSV文件，逗号分隔
df=pd.read_csv('/tmp/test.csv',header=None,sep=',')
length=len(df.values)
for i in range(0,length):
    ele=df.values[i]
    name=ele[0]
    age=ele[1]
    sex=ele[2]
    city=ele[3]
    sql='insert into tb values(%s,%s,%s,%s)' % (name,age,sex,city)
    print(sql)
    ##cur.execute(sql)


# for i in range(0,3):
#     for y in range(0,4):
#         # print(df.values[i][y])
#         name=df.values[i][y]
#         # age=df.values[i][y]
#         # sex = df.values[i][y]
#         # city = df.values[i][y]
#         print(name)

