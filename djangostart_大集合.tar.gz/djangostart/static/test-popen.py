#!/usr/bin/env python3
#_*_ coding:utf-8 _*_

from subprocess import Popen,PIPE

cmd = 'echo 123456 >>/tmp/jjj.txt'
p = Popen(cmd,stdout=PIPE,stderr=PIPE,shell=True)
data = p.communicate()
print(data)