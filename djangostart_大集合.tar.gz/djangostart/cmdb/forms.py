from django import forms

###下面的变量（ip,hostname...）是在view视图中 addForm(request.POST)请求数据中获取到的name值
class addForm(forms.Form):
    ip = forms.GenericIPAddressField()
    hostname = forms.CharField()
    cpu = forms.IntegerField()
    memory = forms.IntegerField()
    disksize = forms.IntegerField()

