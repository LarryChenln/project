from django.shortcuts import render
from django.http import HttpResponse
from .models import mycmdb
from .forms import addForm
# Create your views here.
###password  admin:A12345678
# # example 1
# def add(request):
#     if request.method == 'POST':
#         IP=request.POST.get('ip')
#         hostname=request.POST.get('hostname')
#         cpu=request.POST.get('cpu')
#         memory=request.POST.get('memory')
#         disksize=request.POST.get('disksize')
#         try:
#             ###筛选数据库元素直接使用类 不 需 要  实例化
#             obj=mycmdb.objects.get(ip=IP)
#             if obj.ip == IP:
#                 # print('ok')
#                 obj.hostname=hostname
#                 obj.memory=memory
#                 obj.cpu_core=cpu
#                 obj.disk_size=disksize
#                 obj.save()
#                 return HttpResponse('<p>更新成功</p>')
#         except:
#             cmdb_obj = mycmdb()
#             cmdb_obj.ip = IP
#             cmdb_obj.hostname = hostname
#             cmdb_obj.cpu_core = cpu
#             cmdb_obj.memory = memory
#             cmdb_obj.disk_size = disksize
#             cmdb_obj.save()
#             return HttpResponse('<p>添加成功</p>')
#     return render(request, 'cmdb_add.html', {} )



### example 2 使用form表单验证输入的数据
def add(request):
    if request.method == 'POST':
        FormOjb=addForm(request.POST)
        ###如果验证OK，在form表单获取相应的数据并赋值给下面的变量
        if FormOjb.is_valid():
            IP  = FormOjb.cleaned_data['ip']
            hostname = FormOjb.cleaned_data['hostname']
            cpu = FormOjb.cleaned_data['cpu']
            memory = FormOjb.cleaned_data['memory']
            disksize = FormOjb.cleaned_data['disksize']

            try:
                ###筛选数据库元素直接使用类 不 需 要  实例化
                obj=mycmdb.objects.get(ip=IP)
                if obj.ip == IP:
                    # print('ok')
                    obj.hostname=hostname
                    obj.memory=memory
                    obj.cpu_core=cpu
                    obj.disk_size=disksize
                    obj.save()
                    return HttpResponse('<p>更新成功</p>')
            except:
                cmdb_obj = mycmdb()
                cmdb_obj.ip = IP
                cmdb_obj.hostname = hostname
                cmdb_obj.cpu_core = cpu
                cmdb_obj.memory = memory
                cmdb_obj.disk_size = disksize
                cmdb_obj.save()
                return HttpResponse('<p>添加成功</p>')
        else:
            return HttpResponse('<p>数据类型验证失败</p>')
    return render(request, 'cmdb_add.html', {} )



def Testdb(request):
    try:
        mycmdb.objects.all().delete()
    except:
        return HttpResponse('<p>没有找到要删除的</p>')

    # a=mycmdb.objects.all()
    # result=''
    # for var in a:
    #     if var.hostname=='lnmp':
    #         var.hostname='google'
    #         var.save()

    # patern=mycmdb.objects.all()
    # for i in patern:
    #     if i.hostname=='google':
    #         i.memory=900
    #         i.save()

    # if patern.hostname=='google':
    #     patern.memory=8000
    #     patern.save()

    return HttpResponse("<p>修改成功</p>")



def viewform(request):
    if request.method == 'GET':
        obj=mycmdb.objects.all()
        # for i in obj:
        #     if i.cpu_core == 8:
        #         return render(request,'viewform.html',{'data':i})

    return render(request,'viewform.html',{'data':obj})