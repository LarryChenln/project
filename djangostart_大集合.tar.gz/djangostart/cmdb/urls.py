# from django.conf.urls import url
# from cmdb.views import add
# urlpatterns = [
#     url(r'^add/$',add,name='cmdb_add')
# ]