from django.db import models

# Create your models here.

class mycmdb(models.Model):
    ip=models.GenericIPAddressField(verbose_name=u'IP地址')
    hostname=models.CharField(max_length=50,verbose_name=u'主机名',default='')
    cpu_core=models.IntegerField(verbose_name=u'CPU核心数',default='')
    memory=models.CharField(max_length=200,verbose_name=u'内存大小',default='')
    disk_size=models.CharField(max_length=200,verbose_name=u'磁盘总容量')

    class Meta:
        verbose_name=u'主机资源表'
        verbose_name_plural=verbose_name

    def __str__(self):
        return self.ip




###一对多设计一对多：models.ForeignKey(其他表);
# 一对多：当一张表中创建一行数据时，有一个单选的下拉框（可以被重复选择）
# 多对多：models.ManyToManyField(其他表)
# 多对多：在某表中创建一行数据是，有一个可以多选的下拉框
# 例如：创建用户信息，需要为用户指定多个爱好
# 一对一：models.OneToOneField(其他表)
# 一对一：在某表中创建一行数据时，有一个单选的下拉框（下拉框中的内容被用过一次就消失了


###一对多
class Game(models.Model):
    gname=models.CharField(max_length=50)


class Host(models.Model):
    hostname=models.CharField(max_length=50)
    game=models.ForeignKey('Game')


###多对多,django会自动创建第三张映射表(usergroup_user表)
class UserGroup(models.Model):
    groupname=models.CharField(max_length=50)


class User(models.Model):
    name=models.CharField(max_length=20)
    sex=models.CharField(max_length=20)
    email=models.EmailField(max_length=30)
    usergroup_user=models.ManyToManyField('UserGroup')

    class Meta:
        verbose_name=u'用户信息表'
        verbose_name_plural=verbose_name

    def __str__(self):
        return self.name


###一对一
class User2(models.Model):
    name=models.CharField(max_length=20)
    sex=models.CharField(max_length=20)
    email=models.EmailField(max_length=30)


class Admin2(models.Model):
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=30)
    admin_user2=models.OneToOneField('User2')

