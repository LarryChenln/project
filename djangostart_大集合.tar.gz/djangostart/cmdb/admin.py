from django.contrib import admin

from .models import mycmdb,User
admin.site.register(mycmdb)


class UserAdmin(admin.ModelAdmin):
    list_display = ('name','email')

admin.site.register(User,UserAdmin)

# Register your models here.
