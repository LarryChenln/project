import requests,os,sys
import psutil
import subprocess,os,sys


EXPAND = 1024 * 1024 * 1024
def getip():
    p = subprocess.Popen("ifconfig|grep -A 5 en0|grep inet|tail -1", stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    result = p.communicate()[0]
    result=result.split()
    return result[1]


def hostname():
    p=subprocess.Popen('hostname',stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
    result=p.communicate()
    return str(result[0])


def cpu():
    cores=psutil.cpu_count()
    return int(cores)

def memory():
    mem=int(psutil.virtual_memory()[0] / EXPAND)
    return mem



def disk(path):
    import platform
    st=os.statvfs(path)
    total = (st.f_blocks * st.f_frsize) / EXPAND
    free = (st.f_bavail * st.f_frsize) / EXPAND
    used = (st.f_blocks - st.f_bfree) * st.f_frsize / EXPAND
    return int(total)


url='http://127.0.0.1:8000/cmdb_add/'
# data={'ip':'192.168.2.1','cpu':2,'hostname':'lnmp2','memory':2000,'disksize':500000}
data={}
data["ip"]=getip()
data["cpu"]=cpu()
data["hostname"]=hostname()
data["memory"]=memory()
data["disksize"]=disk('/')
print(data)
stat=requests.post(url,data=data)
if stat.status_code == 200:
    print('update info success !')
else:
    print('failed...')









