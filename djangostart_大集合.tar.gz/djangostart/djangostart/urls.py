"""djangostart URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Import the include() function: from django.conf.urls import url, include
    3. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import url
from django.contrib import admin
from message.views import getform,postform,exe_cmds,viewPvUv
from cmdb.views import add,Testdb,viewform

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^message_form/$', postform,name='mymessage'),
    url(r'^getmessage/$', getform,name='getmessage'),
    url(r'^getmessage/commands.html$',exe_cmds),
    url(r'^exec/$',exe_cmds,name='exeCommands'),
    url(r'^getmessage/viewpvuv.html',viewPvUv),
    # url(r'^getmessage/updatePvdata.html',updatePvdata)
    url(r'^cmdb_add/$',add,name='cmdb_add'),
    url(r'^testdb$',Testdb),
    url(r'^viewform$',viewform,name='viewform'),
    url(r'^cmdb_add/viewform.html/$',viewform,name='viewform')
]
