from django.db import models

# Create your models here.

class UserMessage(models.Model):
    name = models.CharField(max_length=50,verbose_name=u'用户名',default='')
    email = models.EmailField(max_length=50,default='',verbose_name=u'邮箱')
    address = models.CharField(max_length=100,default='',verbose_name=u'地址')
    text = models.CharField(max_length=500,default='',verbose_name=u'留言信息')

    class Meta:
        verbose_name = u'用户留言板'
        verbose_name_plural = verbose_name
        db_table = 'user_message'

    def __str__(self):
        return self.name