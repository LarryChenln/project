import pandas as pd
import json
from subprocess import PIPE,Popen
from django.shortcuts import render
from .models import UserMessage
# Create your views here.

def getform(request):
    if request.method == 'POST':
        name=request.POST.get('name')
        data=UserMessage.objects.filter(name=name)
        return render(request, 'test.html',{'dataall':data})
    return render(request,'test.html')



def postform(request):
    if request.method == 'POST':
        username = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        text = request.POST.get('message')
        # user = UserMessage.objects.filter(name=username)
        User_Message = UserMessage()
        User_Message.name = username
        User_Message.email = email
        User_Message.address = address
        User_Message.text = text
        User_Message.save()
    return render(request,'demo.html')



def exe_cmds(request):
    if request.method == 'POST':
        cmds = request.POST.get('cmds')
        cmd = cmds
        p = Popen(cmd, stdout=PIPE, stderr=PIPE, shell=True)
        results = p.communicate()
        return render(request, 'test.html', {'results': results})
    return render(request,'test.html')



#给js调用的URL
# pv_list=[3000,8000,8732,19802,33398]
# uv_list=[2000,3219,8731,3211,8873]
# time_list=['22/06/18','23/06/18','24/06/18','25/06/18','26/06/18']
#
# dataframe=pd.DataFrame({'time':time_list,'pv':pv_list,'uv':uv_list})
# dataframe.to_csv('/tmp/pdfile.csv',index=False,sep=',')
# def updatePvdata(request):
#     with open('/tmp/pdfile.csv','r')as f:
#         data=f.readlines()
#         return render(request,'update-pv.html',{'data':data})
def getpvuv():
    #mysql data
    pass



def viewPvUv(request):
    if request.method == 'GET':
        #调用函数更新pvuv数据
        data=getpvuv()
        return render(request, 'bar图条viewpvuv.html', {'data':data})