from datetime import datetime
import time
import schedule


def my_print():
    print('I am working ...')
#
# if __name__ == '__main__':
#     schedule.every(5).seconds.do(my_print)
#     #每5s执行 my_print函数
#     while True:
#         schedule.run_pending()
#         time.sleep(1)



# soce=50
# result='及格' if soce >= 60 else '不及格'
# print(result)

def myfun(x):
    x+=1
    return x

print(myfun(9))