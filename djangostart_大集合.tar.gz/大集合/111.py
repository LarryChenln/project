# class my_test(object):
#     def __init__(self,name,sex):
#         self.name = name
#         self.__sex=sex
#     def my_security(self):
#         print('nice to see you')
#
# import sys
#
# p = my_test('larry',22)
# # print(p.name)
# # print(p.my_security())
#
# b=p
# print(sys.getrefcount(p))
# print(b.name)



# import gc
# gc.collect()

# #猴子吃桃子
# x2=1
# for i in range(9,0,-1):
#     x1=(x2+1)*2
#     x2=x1
#
# print(x1)
#
# num=1534
# for i in range(0,9,1):
#     result=num/2 - 1
#     num=result
#
# print(int(num))


#打印菱形图像
# from sys import stdout
# for n in range(4):
#     for i in range(2-n+1):
#         stdout.write(' ')
#     for y in range(2*n+1):
#         stdout.write('*')
#     print()

# ##脚部传参
# import sys
# args=sys.argv[1:]
# if '-h' in args:
#     print('\n This is a test script\nfor example:\npython num1 num2\n')
# elif len(args) != 2:
#     print('args must have two arg')
# else:
#     print('num1 + num2= {0}'.format(args[0]+args[1]))
#

import random
choice=[0]*10+[1]*10
print(random.choice(choice))

import  os
dir = os.getcwd()
li=os.listdir(dir)
print(li)