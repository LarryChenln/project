#!_*_ coding：utf-8 _*_
#pip3.6 install wordcloud

from wordcloud import WordCloud
import jieba,os

d = os.path.dirname(__file__)
f = open(os.path.join(d,'demo.html'),'r').read()

data = ' '.join(jieba.cut(f))
wordcloud = WordCloud(font_path='./simsun.ttf',background_color='white',width=1000,height=800,margin=2).generate(data)

# 导入下面库可以即时显示图片
import matplotlib.pyplot as plt
plt.imshow(wordcloud)
plt.axis("off")
plt.show()

#保存到文件
# wordcloud.to_file('/tmp/词云图片.png')