#!_*_ coding：utf-8 _*_
#pip3.6 install wordcloud

from os import path
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import jieba
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator

d = path.dirname(__file__)
text = open(path.join(d,'demo.html'),'r').read()

text = ' '.join(jieba.cut(text))

alice_coloring = np.array(Image.open(path.join(d, "alice.png")))

# 设置停用词
stopwords = set(STOPWORDS)
stopwords.add("said")

# 你可以通过 mask 参数 来设置词云形状
wc = WordCloud(font_path='./simsun.ttf',background_color="white", max_words=2000, mask=alice_coloring,
               stopwords=stopwords, max_font_size=80, random_state=42)
# generate word cloud
wc.generate(text)

# create coloring from image
image_colors = ImageColorGenerator(alice_coloring)

# show
# 在只设置mask的情况下,你将会得到一个拥有图片形状的词云
plt.imshow(wc, interpolation="bilinear")
plt.axis("off")
plt.figure()

## recolor wordcloud and show
## we could also give color_func=image_colors directly in the constructor
## 我们还可以直接在构造函数中直接给颜色
## 通过这种方式词云将会按照给定的图片颜色布局生成字体颜色策略

plt.imshow(wc.recolor(color_func=image_colors), interpolation="bilinear")
plt.axis("off")
plt.figure()

plt.imshow(alice_coloring, cmap=plt.cm.gray, interpolation="bilinear")
plt.axis("off")
plt.show()