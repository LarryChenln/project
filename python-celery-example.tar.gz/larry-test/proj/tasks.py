from __future__ import absolute_import
import datetime
from .celery import app
from time import sleep


@app.task
def myadd(a,b):
    sleep(2)
    # print(a+b)
    return a+b





@app.task
def mypri():
    for i in range(1,10):
        with open('/tmp/a.log','a')as f:
            f.write('\r\n----'+str(datetime.datetime.now()))
        sleep(1)
    return 'see you again ...'





