from __future__ import absolute_import

CELERY_RESULT_BACKEND='redis://172.16.1.101:6379/6'
BROKER_URL='redis://172.16.1.101:6379/5'
CELERY_TIMEZONE='Asia/Shanghai'



###定时任务，每隔10s 执行 mypri函数   ##启动任务命令： celery -A proj  beat

CELERY_TIMEZONE = 'UTC'
CELERYBEAT_SCHEDULE = {
    'taskA_schedule': {
         'task': 'proj.tasks.mypri',
         'schedule':10
    },
}


#
# CELERY_TIMEZONE = 'UTC'
#  CELERYBEAT_SCHEDULE = {
#      'taskA_schedule' : {
#          'task':'tasks.taskA',
#          'schedule':20,
#          'args':(5,6)
#      },
#      'taskB_scheduler' : {
#          'task':"tasks.taskB",        "schedule":200,
#         "args":(10,20,30)
#     },
#     'add_schedule': {
#         "task":"tasks.add",
#         "schedule":10,
#         "args":(1,2)
#     }
# }

# 其中定义了3个定时任务,即每隔20s执行taskA任务，参数为(5,6),每隔200s执行taskB任务,参数为(10,20,30),每隔10s执行add任务，参数为(1,2).通过下列命令启动一个定时任务:

