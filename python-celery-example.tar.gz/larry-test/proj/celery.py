from __future__ import absolute_import
### pip3.6 install redis
### pip3 install Celery 安装celery服务(python3/bin/celery)
### celery -A project-celery(包同级目录） worker -B -l info
### 有定时任务加 -B


from celery import Celery

app = Celery('proj',include=['proj.tasks'])
app.config_from_object('proj.config')

if __name__ == '__main__':
    app.start()
