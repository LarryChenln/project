
# _*_ coding:utf-8 _*_
__author__ = 'larry'
__date__ = '2018/11/8 5:02 PM'

### 注意  调用delay函数即可启动任务 这个函数的效果是发送一条消息到broker中去，这个消息包括要执行的函数已经执行函数的参数，还有一些其他信息，具体的可以看Celery的文档
### celery服务 启动命令 python3/bin/celery -A proj worker -l info

###有定时任务，启动加参数 beat  example : celery -A proj  beat



from proj.tasks import mypri
from proj.tasks import myadd


obj=myadd.delay(1,8)
print(obj)
print(obj.status)


aa=mypri.delay()
print(aa)