scrapy 爬虫
1.  pip3.6 install scrapy #按照Twisted时报错，下载后再重新install scrapy
2.  https://files.pythonhosted.org/packages/90/50/4c315ce5d119f67189d1819629cae7908ca0b0a6c572980df5cc6942bc22/Twisted-18.7.0.tar.bz2
    tar jxvf Twisted-18.7.0.tar.bz2
    cd Twisted-18.7.0
    python3.6 setup install


3.  安装完scrapy，创建项目
    scrapy startproject spider_objects
    根据提示创建spider文件