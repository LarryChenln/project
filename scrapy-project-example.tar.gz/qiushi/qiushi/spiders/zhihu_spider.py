# -*- coding: utf-8 -*-
import scrapy,re
from qiushi.items import ZhihuItem
from scrapy.selector import Selector

class ZhihuSpider(scrapy.Spider):
    name = 'zhihu_spider'
    allowed_domains = ['www.zhihu.com']
    start_urls = ['https://www.zhihu.com/']

    def parse(self, response):
        # selector=Selector(response)
        text_list=response.xpath("//div[@class='ContentLayout-mainColumn']//div[@class='Card HomeMainItem']")
        print(text_list)
        # print(text_list)
        # for i_iteam in text_list:
        #     aitem=ZhihuItem()
        #     aitem["context_from"]=i_iteam.xpath(".//div[@class='FeedSource']/div[@class='FeedSource-firstline']/span/a[@class='TopicLink']/div[@class='Popover']/div/text()").extract_first()
        # #     aitem["author"]=i_iteam.xpath(".//a[@class='UserLink-link']/text()").extract_first()
        # #
        # #     uattr=i_iteam.xpath(".//div[@class='FeedSource']/div[@class='AuthorInfo FeedSource-byline AuthorInfo--plain']/div[@class='AuthorInfo-content']/div[@class='AuthorInfo-detail']/div[@class='AuthorInfo-badge']/div[@class='RichText ztext AuthorInfo-badgeText']/text()").extract_first()
        # #     if uattr:
        # #         aitem["userattr"] = uattr
        # #     else:
        # #         aitem["userattr"] = ''
        # #
        # #     aitem["title"]=i_iteam.xpath(".//div[@class='ContentItem AnswerItem']/h2[@class='ContentItem-title']/div/a/text()")
        # #
        #     print(aitem)
        # next_link=response.xpath("//span[@class='next']/a/@href").extract()
        # if next_link:
        #     next_link=next_link[0]
        #     yield scrapy.Request("https://www.douban.com/group/explore/ent"+str(next_link),callback=self.parse)
        # else:
        #     print('page end ...')

