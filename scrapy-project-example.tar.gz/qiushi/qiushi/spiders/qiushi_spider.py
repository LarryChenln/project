# -*- coding: utf-8 -*-
import scrapy
from qiushi.items import QiushiItem

class QiushiSpiderSpider(scrapy.Spider):
    name = 'qiushi_spider'
    allowed_domains = ['www.qiushibaike.com']
    start_urls = ['https://www.qiushibaike.com/text/']

    def parse(self, response):
        # print(response.text)
        text_list=response.xpath("//div[@id='content']/div[@class='content-block clearfix']/div[@id='content-left']/div").extract()
        print(text_list)
        for i_iteam in text_list:
            aitem=QiushiItem()
            aitem["username"]=i_iteam.xpath(".//div[@class='author clearfix']/a[2]/h2/text()").extract_first()
        #     aitem["context"]=i_iteam.xpath(".//div/a[@class='contentHerf']/div[@class='content']/span/text()").extract_first()
        #     aitem["vote"]=i_iteam.xpath(".//div[@class='stats']/span[@class='stats-vote']/i[@class='number']//text()").extract_first()
        #     aitem["comments"]=i_iteam.xpath(".//div[@class='stats']/span[@class='stats-comments']/a/text()").extract()
        #     aitem["desc"]=i_iteam.xpath(".//a[@class='indexGodCmt']/div[@class='cmtMain']/div[@class='main-text']/text()").extract_first()
            yield aitem