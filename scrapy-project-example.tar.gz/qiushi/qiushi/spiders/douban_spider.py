# -*- coding: utf-8 -*-
import scrapy,re
from qiushi.items import DoubanItem

class DoubanSpider(scrapy.Spider):
    name = 'douban_spider'
    allowed_domains = ['www.douban.com']
    start_urls = ['https://www.douban.com/group/explore/ent']

    def parse(self, response):
        # print(response.text)
        text_list=response.xpath("//div[@id='content']/div[@class='grid-16-8 clearfix']/div[@class='article']//div[@class='channel-item']")
        # print(text_list)
        # # print(text_list)
        for i_iteam in text_list:
            aitem=DoubanItem()
            aitem["title"]=i_iteam.xpath(".//div[@class='bd']/h3/a/text()").extract_first()
            aitem["douban_text"]=re.sub('\r\n','',i_iteam.xpath(".//div[@class='bd']/div[@class='block']/p/text()").extract_first())
            aitem["douban_item"]=i_iteam.xpath(".//div[@class='bd']/div[@class='source']/span[@class='from']/a/text()").extract_first()
            aitem["douban_likes"]=i_iteam.xpath(".//div[@class='likes']/text()").extract_first()
            # aitem["desc"]=i_iteam.xpath(".//a[@class='indexGodCmt']/div[@class='cmtMain']/div[@class='main-text']/text()").extract_first()
            yield aitem
        next_link=response.xpath("//span[@class='next']/a/@href").extract()
        if next_link:
            next_link=next_link[0]
            yield scrapy.Request("https://www.douban.com/group/explore/ent"+str(next_link),callback=self.parse)
        else:
            print('page end ...')

