# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class QiushiItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    username=scrapy.Field()
    context=scrapy.Field()
    vote=scrapy.Field()
    comments=scrapy.Field()
    desc=scrapy.Field()

class DoubanItem(scrapy.Item):
    title=scrapy.Field()
    douban_text=scrapy.Field()
    douban_item=scrapy.Field()
    douban_likes=scrapy.Field()

class ZhihuItem(scrapy.Item):
    context_from=scrapy.Item()
    author=scrapy.Item()
    userattr=scrapy.Item()
    title=scrapy.Item()
    context=scrapy.Item()
    vote=scrapy.Item()
    comments=scrapy.Item()

class PicItem(scrapy.Item):
    image_urls=scrapy.Item()
    images=scrapy.Item()