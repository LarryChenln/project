
##使用webdriver selenium 下载煎蛋图片
import  requests,json,re
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from pyquery import PyQuery as pq
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import time
import os,sys
from urllib import request

header={
'Content-type':'application/x-www-form-urlencoded',
'Origin':'https://music.163.com',
'Referer':'https://music.163.com/',
'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
}



jd_url='http://jandan.net/ooxx/page-%d#comments'
def get_jd_pic_url(url):
    browser = webdriver.Chrome()
    ###如果网络有延迟，请求等待时间10秒，默认等待0秒
    browser.implicitly_wait(300)
    ###cookie处理
    # cookie = {'name':'larry','vaule':'123456'}
    # browser.add_cookie(cookie)

    ##设置网页下载时长超时时间秒
    browser.set_page_load_timeout(600)
    ###截取当前页面屏幕
    ###browser.save_screenshot('/tmp/meinv1.png')
    browser.get(url)
    soup = BeautifulSoup(browser.page_source, 'html.parser', from_encoding='utf-8')
    all_data=str(soup.select("div[class='text'] p a"))
    all_li=all_data.split()
    patern=re.compile(r'.*href=\"(?P<picUrl>.*\.jpg).*')
    download_dir='/tmp/download'
    if not os.path.exists(download_dir):
        os.mkdir(download_dir)
    for i in all_li:
        link = re.search(patern, i)
        if link:
            pic_link='http:' + link.group('picUrl')
            print(pic_link)
            with open(download_dir+'/jd_links.txt','a')as f:
                f.writelines(str(pic_link)+'\n\r')

    browser.close()



def get_all_pic_links():
    for i in range(1,20):
        cur_url=jd_url % (i)
        get_jd_pic_url(cur_url)
        time.sleep(5)



def downloadPics():
    if not os.path.exists('/tmp/download/jd_links.txt'):
        return False
    pics_dir = '/tmp/download/pics/'
    if not os.path.exists(pics_dir):
        os.mkdir(pics_dir)
    with open('/tmp/download/jd_links.txt','r')as f:
        num=1
        for link in f.readlines():
            try:
                if not os.path.exists(pics_dir + str(num) + '.jpg'):
                    request.urlretrieve(url=link, filename=pics_dir + str(num) + '.jpg')
                num += 1
            except:
                pass




if __name__ == '__main__':
    # get_all_pic_links()
    ##同时进行浏览器间隙许加长
    downloadPics()








# get_jd_pic_url(jd_url %(41))


# li='<a class="view_img_link" href="//ws1.sinaimg.cn/large/c75eaeeegy1fu01s5dwyoj20bo0go405.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx4.sinaimg.cn/large/c75eaeeegy1fu01rn4sb4j20u01hcgne.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1fu00nvo255j30f50n1jtw.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx2.sinaimg.cn/large/0076BSS5ly1fu00nmvyutj30lc0u10vi.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx2.sinaimg.cn/large/661eb95cly1fst8skqnppj20dw0lh41e.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx4.sinaimg.cn/large/661eb95cly1fst8sjkwzsj21kw2d61kx.jpg" target="_blank">[查看原图]</a>, <a class="view_bad" href="javascript:;">[手贱一回]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/0076BSS5ly1ftzzgj10soj30zk1hbtkz.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ws2.sinaimg.cn/large/898c39e4gy1ftzyctdkcmj20b40go0vt.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/0076BSS5ly1ftzy8x1yfuj30sg0zkwif.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1ftzy1uvaiej30ub0kudki.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1ftzxvfqcxrj30hs0smgok.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx2.sinaimg.cn/large/0076BSS5ly1ftzx2jtzjsj30m90xcjxh.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1ftzw9oeaecj30rr15e7e1.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx4.sinaimg.cn/large/0076BSS5ly1ftzvungds9j30mb0tvgmx.jpg" target="_blank">[查看原图]</a>, <a class="view_bad" href="javascript:;">[手贱一回]</a>, <a class="view_img_link" href="//ws1.sinaimg.cn/large/c75eaeeegy1ftzv3oybihj20g40lhta1.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx1.sinaimg.cn/large/0076BSS5ly1ftzukcc9nuj31kw11xqv5.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/a8e6d38dly1ftzuji0mb5j20k00jywik.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1ftzturf26uj30u00u0jt0.jpg" target="_blank">[查看原图]</a>, <a class="view_bad" href="javascript:;">[手贱一回]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/0076BSS5ly1ftztcsjp4yj30m80xc79g.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1ftzstzukaxj30j60kttf9.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1ftzsippd8zj30kq0tddh4.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ww3.sinaimg.cn/large/0073ob6Pgy1ftzsdc8bx4j30u00tzaet.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//ws2.sinaimg.cn/large/e0e4ecc3gy1ftzsa670z6g20dw0711ir.gif" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx2.sinaimg.cn/large/e0e4ecc3gy1ftzs6gxo0tj20ly0wsn2g.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/b695732fgy1ftzq5cubk4j21kw11x7hy.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/b695732fgy1ftzq5dyhwoj21hc0zkagz.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx1.sinaimg.cn/large/b695732fgy1ftzq5del92j21hc0zldlp.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/b695732fgy1ftzq5d3qxej21kw11yqi2.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx4.sinaimg.cn/large/b695732fgy1ftzq5eqb9zj21kw0w04cz.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/b695732fgy1ftzq5d66wbj21hc0xcgp3.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx3.sinaimg.cn/large/b695732fgy1ftzq5drwcjj21hc142h2v.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx2.sinaimg.cn/large/b695732fgy1ftzq5dehq1j21hc0xcwms.jpg" target="_blank">[查看原图]</a>, <a class="view_img_link" href="//wx1.sinaimg.cn/large/b695732fgy1ftzq5f2azuj21kw1044am.jpg" target="_blank">[查看原图]</a>]'
# a=li.split()
#
# patern=re.compile(r'.*href=\"(?P<picUrl>.*\.jpg).*')
# for i in a:
#     # print(i)
#     link=re.search(patern,i)
#     if link:
#         print('http:'+link.group('picUrl'))


# jd_url='https://www.qiushibaike.com/text/page/'
# def get_qiushi(url):、
#     html=requests.get(url,headers=header)
#     data=html.text
#     soup=BeautifulSoup(data,"lxml")
#     all_s=str(soup.select('div[class="content"] span'))
#     all_s=re.sub('<span>','',all_s)
#     all_s=re.sub(r'</span>','',all_s)
#     all_s=re.sub(r'<br/>','\r\n',all_s)
#     print(all_s)
#
# def main():
#     for i in range(1,2):
#         print((qs_url+str(i)+'/'))
#         get_qiushi(qs_url+str(i)+'/')
#
# if __name__ == '__main__':
#     main()

# keyword=input('Pls input song name:')
# search_url='https://music.163.com/#/search/m/?s=%s&type=1'
# html=requests.post(search_url %(keyword),headers=header)
# html=html.text
# # print(html)
# #创建beautifu、lsoup对象
# soup=BeautifulSoup(html,"lxml")

##过滤出a标签，并且class属性是sister和id属性是link1的,由于Python中class是关键字所以下边要用class_代表class属性。
# print (soup.find_all("a",class_="sister",id="link1"))
##通过select标签查询
# print(soup.select('a'))
# print(soup.select('div'))
# ##通过类名查找和ID名查找
# print(soup.select('.sister'))
# print(soup.select('#link1'))
##属性查找,a标签并且class属性是sister的
# print(soup.select('a[class="sister"]'))
##p 标签下的a标签且class属性是sister的
# print(soup.select('p a[class="sister"]'))
# print(soup.select("div[class='text'] a"))
#
#   ##### for example re
#         htmldata='''
#         <div>
#             <a href='.'>
#              <p class="sister" id="link1"> 111 </p>
#              </a>
#         </div>
#         '''
#         soup=BeautifulSoup(htmldata,"lxml")
#         #查找div标签下子标签是a的标签下的子标签是p的标签，并且class属性是sister的
#         ele=soup.select("div a p[class='sister']")
#         print(ele)
#         #正则条件转义<> ，(?P<>尖括号内的变量名是匹配到的内容的变量引用,这个小括号是区间)
#         patern=re.compile(r'\<p.*\>(?P<element>.*)\</p\>')
#         result=re.search(patern,str(ele))
#         #对匹配到的ele进行字符转义,取匹配到的变量区间
#         print(result.group('element'))

