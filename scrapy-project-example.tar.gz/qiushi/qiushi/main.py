from scrapy import cmdline
cmdline.execute("scrapy crawl qiushi_spider".split())
# cmdline.execute("scrapy crawl douban_spider".split(、))
# cmdline.execute("scrapy crawl zhihu_spider".split())

